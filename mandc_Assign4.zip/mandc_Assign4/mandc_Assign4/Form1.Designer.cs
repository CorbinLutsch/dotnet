﻿namespace mandc_Assign4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.xMinTxt = new System.Windows.Forms.TextBox();
            this.xMaxTxt = new System.Windows.Forms.TextBox();
            this.xIntervalTxt = new System.Windows.Forms.TextBox();
            this.yMinTxt = new System.Windows.Forms.TextBox();
            this.yMaxTxt = new System.Windows.Forms.TextBox();
            this.yIntervalTxt = new System.Windows.Forms.TextBox();
            this.lblxMin = new System.Windows.Forms.Label();
            this.lblxMax = new System.Windows.Forms.Label();
            this.lblxInterval = new System.Windows.Forms.Label();
            this.lblyMin = new System.Windows.Forms.Label();
            this.lblyMax = new System.Windows.Forms.Label();
            this.lblyInterval = new System.Windows.Forms.Label();
            this.btnAxis = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.mTxt = new System.Windows.Forms.TextBox();
            this.bTxt = new System.Windows.Forms.TextBox();
            this.a1Txt = new System.Windows.Forms.TextBox();
            this.b1Txt = new System.Windows.Forms.TextBox();
            this.c1Txt = new System.Windows.Forms.TextBox();
            this.b2Txt = new System.Windows.Forms.TextBox();
            this.a2Txt = new System.Windows.Forms.TextBox();
            this.c2Txt = new System.Windows.Forms.TextBox();
            this.d2Txt = new System.Windows.Forms.TextBox();
            this.hTxt = new System.Windows.Forms.TextBox();
            this.kTxt = new System.Windows.Forms.TextBox();
            this.rTxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnGraph = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.color1 = new System.Windows.Forms.Button();
            this.color2 = new System.Windows.Forms.Button();
            this.color3 = new System.Windows.Forms.Button();
            this.color4 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.graph = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb6 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.graph)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            this.SuspendLayout();
            // 
            // xMinTxt
            // 
            this.xMinTxt.Location = new System.Drawing.Point(692, 42);
            this.xMinTxt.Name = "xMinTxt";
            this.xMinTxt.Size = new System.Drawing.Size(100, 20);
            this.xMinTxt.TabIndex = 1;
            this.xMinTxt.Text = "-100";
            // 
            // xMaxTxt
            // 
            this.xMaxTxt.Location = new System.Drawing.Point(692, 90);
            this.xMaxTxt.Name = "xMaxTxt";
            this.xMaxTxt.Size = new System.Drawing.Size(100, 20);
            this.xMaxTxt.TabIndex = 2;
            this.xMaxTxt.Text = "100";
            // 
            // xIntervalTxt
            // 
            this.xIntervalTxt.Location = new System.Drawing.Point(692, 224);
            this.xIntervalTxt.Name = "xIntervalTxt";
            this.xIntervalTxt.Size = new System.Drawing.Size(100, 20);
            this.xIntervalTxt.TabIndex = 3;
            this.xIntervalTxt.Text = "10";
            // 
            // yMinTxt
            // 
            this.yMinTxt.Location = new System.Drawing.Point(692, 134);
            this.yMinTxt.Name = "yMinTxt";
            this.yMinTxt.Size = new System.Drawing.Size(100, 20);
            this.yMinTxt.TabIndex = 4;
            this.yMinTxt.Text = "-100";
            // 
            // yMaxTxt
            // 
            this.yMaxTxt.Location = new System.Drawing.Point(692, 178);
            this.yMaxTxt.Name = "yMaxTxt";
            this.yMaxTxt.Size = new System.Drawing.Size(100, 20);
            this.yMaxTxt.TabIndex = 5;
            this.yMaxTxt.Text = "100";
            // 
            // yIntervalTxt
            // 
            this.yIntervalTxt.Location = new System.Drawing.Point(692, 270);
            this.yIntervalTxt.Name = "yIntervalTxt";
            this.yIntervalTxt.Size = new System.Drawing.Size(100, 20);
            this.yIntervalTxt.TabIndex = 6;
            this.yIntervalTxt.Text = "10";
            // 
            // lblxMin
            // 
            this.lblxMin.AutoSize = true;
            this.lblxMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblxMin.ForeColor = System.Drawing.Color.White;
            this.lblxMin.Location = new System.Drawing.Point(626, 40);
            this.lblxMin.Name = "lblxMin";
            this.lblxMin.Size = new System.Drawing.Size(60, 20);
            this.lblxMin.TabIndex = 7;
            this.lblxMin.Text = "X-min:";
            // 
            // lblxMax
            // 
            this.lblxMax.AutoSize = true;
            this.lblxMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblxMax.ForeColor = System.Drawing.Color.White;
            this.lblxMax.Location = new System.Drawing.Point(622, 88);
            this.lblxMax.Name = "lblxMax";
            this.lblxMax.Size = new System.Drawing.Size(64, 20);
            this.lblxMax.TabIndex = 8;
            this.lblxMax.Text = "X-max:";
            // 
            // lblxInterval
            // 
            this.lblxInterval.AutoSize = true;
            this.lblxInterval.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblxInterval.ForeColor = System.Drawing.Color.White;
            this.lblxInterval.Location = new System.Drawing.Point(596, 222);
            this.lblxInterval.Name = "lblxInterval";
            this.lblxInterval.Size = new System.Drawing.Size(90, 20);
            this.lblxInterval.TabIndex = 9;
            this.lblxInterval.Text = "X-interval:";
            // 
            // lblyMin
            // 
            this.lblyMin.AutoSize = true;
            this.lblyMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblyMin.ForeColor = System.Drawing.Color.White;
            this.lblyMin.Location = new System.Drawing.Point(626, 134);
            this.lblyMin.Name = "lblyMin";
            this.lblyMin.Size = new System.Drawing.Size(60, 20);
            this.lblyMin.TabIndex = 10;
            this.lblyMin.Text = "Y-min:";
            // 
            // lblyMax
            // 
            this.lblyMax.AutoSize = true;
            this.lblyMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblyMax.ForeColor = System.Drawing.Color.White;
            this.lblyMax.Location = new System.Drawing.Point(622, 178);
            this.lblyMax.Name = "lblyMax";
            this.lblyMax.Size = new System.Drawing.Size(64, 20);
            this.lblyMax.TabIndex = 11;
            this.lblyMax.Text = "Y-max:";
            // 
            // lblyInterval
            // 
            this.lblyInterval.AutoSize = true;
            this.lblyInterval.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblyInterval.ForeColor = System.Drawing.Color.White;
            this.lblyInterval.Location = new System.Drawing.Point(596, 268);
            this.lblyInterval.Name = "lblyInterval";
            this.lblyInterval.Size = new System.Drawing.Size(90, 20);
            this.lblyInterval.TabIndex = 12;
            this.lblyInterval.Text = "Y-interval:";
            // 
            // btnAxis
            // 
            this.btnAxis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAxis.Location = new System.Drawing.Point(692, 307);
            this.btnAxis.Name = "btnAxis";
            this.btnAxis.Size = new System.Drawing.Size(121, 50);
            this.btnAxis.TabIndex = 13;
            this.btnAxis.Text = "Update Axis";
            this.btnAxis.UseVisualStyleBackColor = true;
            this.btnAxis.Click += new System.EventHandler(this.btnAxis_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(564, 307);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(123, 50);
            this.btnReset.TabIndex = 14;
            this.btnReset.Text = "Restore Defaults";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(86, 383);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 33);
            this.label1.TabIndex = 15;
            this.label1.Text = "Y = ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(234, 385);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 33);
            this.label2.TabIndex = 16;
            this.label2.Text = "X";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(86, 448);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 33);
            this.label3.TabIndex = 17;
            this.label3.Text = "Y = ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(86, 510);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 33);
            this.label4.TabIndex = 18;
            this.label4.Text = "Y = ";
            // 
            // mTxt
            // 
            this.mTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mTxt.Location = new System.Drawing.Point(150, 385);
            this.mTxt.Name = "mTxt";
            this.mTxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mTxt.Size = new System.Drawing.Size(78, 31);
            this.mTxt.TabIndex = 26;
            this.mTxt.Text = "a";
            this.mTxt.Enter += new System.EventHandler(this.mTxt_Enter);
            this.mTxt.Leave += new System.EventHandler(this.mTxt_Leave);
            // 
            // bTxt
            // 
            this.bTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bTxt.Location = new System.Drawing.Point(334, 385);
            this.bTxt.Name = "bTxt";
            this.bTxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bTxt.Size = new System.Drawing.Size(78, 31);
            this.bTxt.TabIndex = 27;
            this.bTxt.Text = "b";
            this.bTxt.Enter += new System.EventHandler(this.bTxt_Enter);
            this.bTxt.Leave += new System.EventHandler(this.bTxt_Leave);
            // 
            // a1Txt
            // 
            this.a1Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a1Txt.Location = new System.Drawing.Point(150, 448);
            this.a1Txt.Name = "a1Txt";
            this.a1Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a1Txt.Size = new System.Drawing.Size(78, 31);
            this.a1Txt.TabIndex = 28;
            this.a1Txt.Text = "a";
            this.a1Txt.Enter += new System.EventHandler(this.a1Txt_Enter);
            this.a1Txt.Leave += new System.EventHandler(this.a1Txt_Leave);
            // 
            // b1Txt
            // 
            this.b1Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1Txt.Location = new System.Drawing.Point(334, 448);
            this.b1Txt.Name = "b1Txt";
            this.b1Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b1Txt.Size = new System.Drawing.Size(78, 31);
            this.b1Txt.TabIndex = 29;
            this.b1Txt.Text = "b";
            this.b1Txt.Enter += new System.EventHandler(this.b1Txt_Enter);
            this.b1Txt.Leave += new System.EventHandler(this.b1Txt_Leave);
            // 
            // c1Txt
            // 
            this.c1Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1Txt.Location = new System.Drawing.Point(523, 452);
            this.c1Txt.Name = "c1Txt";
            this.c1Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.c1Txt.Size = new System.Drawing.Size(85, 31);
            this.c1Txt.TabIndex = 30;
            this.c1Txt.Text = "c";
            this.c1Txt.Enter += new System.EventHandler(this.c1Txt_Enter);
            this.c1Txt.Leave += new System.EventHandler(this.c1Txt_Leave);
            // 
            // b2Txt
            // 
            this.b2Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2Txt.Location = new System.Drawing.Point(334, 517);
            this.b2Txt.Name = "b2Txt";
            this.b2Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b2Txt.Size = new System.Drawing.Size(78, 31);
            this.b2Txt.TabIndex = 31;
            this.b2Txt.Text = "b";
            this.b2Txt.Enter += new System.EventHandler(this.b2Txt_Enter);
            this.b2Txt.Leave += new System.EventHandler(this.b2Txt_Leave);
            // 
            // a2Txt
            // 
            this.a2Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a2Txt.Location = new System.Drawing.Point(150, 514);
            this.a2Txt.Name = "a2Txt";
            this.a2Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.a2Txt.Size = new System.Drawing.Size(78, 31);
            this.a2Txt.TabIndex = 32;
            this.a2Txt.Text = "a";
            this.a2Txt.Enter += new System.EventHandler(this.a2Txt_Enter);
            this.a2Txt.Leave += new System.EventHandler(this.a2Txt_Leave);
            // 
            // c2Txt
            // 
            this.c2Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c2Txt.Location = new System.Drawing.Point(523, 514);
            this.c2Txt.Name = "c2Txt";
            this.c2Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.c2Txt.Size = new System.Drawing.Size(85, 31);
            this.c2Txt.TabIndex = 33;
            this.c2Txt.Text = "c";
            this.c2Txt.Enter += new System.EventHandler(this.c2Txt_Enter);
            this.c2Txt.Leave += new System.EventHandler(this.c2Txt_Leave);
            // 
            // d2Txt
            // 
            this.d2Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d2Txt.Location = new System.Drawing.Point(692, 516);
            this.d2Txt.Name = "d2Txt";
            this.d2Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.d2Txt.Size = new System.Drawing.Size(85, 31);
            this.d2Txt.TabIndex = 34;
            this.d2Txt.Text = "d";
            this.d2Txt.Enter += new System.EventHandler(this.d2Txt_Enter);
            this.d2Txt.Leave += new System.EventHandler(this.d2Txt_Leave);
            // 
            // hTxt
            // 
            this.hTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hTxt.Location = new System.Drawing.Point(388, 580);
            this.hTxt.Name = "hTxt";
            this.hTxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hTxt.Size = new System.Drawing.Size(78, 31);
            this.hTxt.TabIndex = 35;
            this.hTxt.Text = "h";
            this.hTxt.Enter += new System.EventHandler(this.hTxt_Enter);
            this.hTxt.Leave += new System.EventHandler(this.hTxt_Leave);
            // 
            // kTxt
            // 
            this.kTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kTxt.Location = new System.Drawing.Point(649, 579);
            this.kTxt.Name = "kTxt";
            this.kTxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.kTxt.Size = new System.Drawing.Size(80, 31);
            this.kTxt.TabIndex = 36;
            this.kTxt.Text = "k";
            this.kTxt.Enter += new System.EventHandler(this.kTxt_Enter);
            this.kTxt.Leave += new System.EventHandler(this.kTxt_Leave);
            // 
            // rTxt
            // 
            this.rTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rTxt.Location = new System.Drawing.Point(150, 576);
            this.rTxt.Name = "rTxt";
            this.rTxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rTxt.Size = new System.Drawing.Size(78, 31);
            this.rTxt.TabIndex = 37;
            this.rTxt.Text = "r";
            this.rTxt.Enter += new System.EventHandler(this.rTxt_Enter);
            this.rTxt.Leave += new System.EventHandler(this.rTxt_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(275, 369);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 61);
            this.label7.TabIndex = 39;
            this.label7.Text = "+";
            // 
            // btnGraph
            // 
            this.btnGraph.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGraph.Location = new System.Drawing.Point(564, 363);
            this.btnGraph.Name = "btnGraph";
            this.btnGraph.Size = new System.Drawing.Size(249, 44);
            this.btnGraph.TabIndex = 45;
            this.btnGraph.Text = "Graph";
            this.btnGraph.UseVisualStyleBackColor = true;
            this.btnGraph.Click += new System.EventHandler(this.btnGraph_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(269, 582);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 33);
            this.label5.TabIndex = 46;
            this.label5.Text = "=";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(275, 430);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 61);
            this.label6.TabIndex = 47;
            this.label6.Text = "+";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(275, 498);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 61);
            this.label8.TabIndex = 48;
            this.label8.Text = "+";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(516, 562);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 61);
            this.label9.TabIndex = 49;
            this.label9.Text = "+";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(458, 437);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 61);
            this.label10.TabIndex = 50;
            this.label10.Text = "+";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(458, 498);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 61);
            this.label11.TabIndex = 51;
            this.label11.Text = "+";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(643, 498);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 61);
            this.label13.TabIndex = 53;
            this.label13.Text = "+";
            // 
            // color1
            // 
            this.color1.BackColor = System.Drawing.Color.White;
            this.color1.Location = new System.Drawing.Point(22, 381);
            this.color1.Name = "color1";
            this.color1.Size = new System.Drawing.Size(58, 45);
            this.color1.TabIndex = 54;
            this.color1.UseVisualStyleBackColor = false;
            this.color1.Click += new System.EventHandler(this.color1_Click);
            // 
            // color2
            // 
            this.color2.BackColor = System.Drawing.Color.Red;
            this.color2.Location = new System.Drawing.Point(22, 438);
            this.color2.Name = "color2";
            this.color2.Size = new System.Drawing.Size(58, 45);
            this.color2.TabIndex = 55;
            this.color2.UseVisualStyleBackColor = false;
            this.color2.Click += new System.EventHandler(this.color2_Click);
            // 
            // color3
            // 
            this.color3.BackColor = System.Drawing.Color.Green;
            this.color3.Location = new System.Drawing.Point(22, 498);
            this.color3.Name = "color3";
            this.color3.Size = new System.Drawing.Size(58, 45);
            this.color3.TabIndex = 56;
            this.color3.UseVisualStyleBackColor = false;
            this.color3.Click += new System.EventHandler(this.color3_Click);
            // 
            // color4
            // 
            this.color4.BackColor = System.Drawing.Color.Blue;
            this.color4.Location = new System.Drawing.Point(22, 562);
            this.color4.Name = "color4";
            this.color4.Size = new System.Drawing.Size(58, 45);
            this.color4.TabIndex = 57;
            this.color4.UseVisualStyleBackColor = false;
            this.color4.Click += new System.EventHandler(this.color4_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(234, 448);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 33);
            this.label14.TabIndex = 58;
            this.label14.Text = "X";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(234, 515);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 33);
            this.label15.TabIndex = 59;
            this.label15.Text = "X";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(417, 448);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 33);
            this.label16.TabIndex = 60;
            this.label16.Text = "X";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(417, 514);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 33);
            this.label17.TabIndex = 61;
            this.label17.Text = "X";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(614, 512);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 33);
            this.label18.TabIndex = 62;
            this.label18.Text = "X";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(262, 437);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 20);
            this.label19.TabIndex = 63;
            this.label19.Text = "2";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(445, 498);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(19, 20);
            this.label20.TabIndex = 64;
            this.label20.Text = "2";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(262, 498);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(19, 20);
            this.label21.TabIndex = 65;
            this.label21.Text = "3";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(312, 578);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 33);
            this.label22.TabIndex = 66;
            this.label22.Text = "( X - ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(572, 577);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(85, 33);
            this.label23.TabIndex = 67;
            this.label23.Text = "( Y - ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(472, 578);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(26, 33);
            this.label24.TabIndex = 68;
            this.label24.Text = ")";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(735, 577);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 33);
            this.label25.TabIndex = 69;
            this.label25.Text = ")";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(488, 562);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 20);
            this.label26.TabIndex = 70;
            this.label26.Text = "2";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(750, 562);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 20);
            this.label27.TabIndex = 71;
            this.label27.Text = "2";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(230, 559);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 20);
            this.label28.TabIndex = 72;
            this.label28.Text = "2";
            // 
            // pb5
            // 
            this.pb5.Image = global::mandc_Assign4.Properties.Resources.info_512;
            this.pb5.Location = new System.Drawing.Point(492, 592);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(23, 23);
            this.pb5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb5.TabIndex = 74;
            this.pb5.TabStop = false;
            // 
            // graph
            // 
            this.graph.BackColor = System.Drawing.Color.Black;
            this.graph.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.graph.Location = new System.Drawing.Point(29, 12);
            this.graph.Name = "graph";
            this.graph.Size = new System.Drawing.Size(533, 345);
            this.graph.TabIndex = 0;
            this.graph.TabStop = false;
            // 
            // pb1
            // 
            this.pb1.Image = global::mandc_Assign4.Properties.Resources.info_512;
            this.pb1.Location = new System.Drawing.Point(418, 393);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(23, 23);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb1.TabIndex = 75;
            this.pb1.TabStop = false;
            // 
            // pb2
            // 
            this.pb2.Image = global::mandc_Assign4.Properties.Resources.info_512;
            this.pb2.Location = new System.Drawing.Point(614, 458);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(23, 23);
            this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb2.TabIndex = 76;
            this.pb2.TabStop = false;
            // 
            // pb3
            // 
            this.pb3.Image = global::mandc_Assign4.Properties.Resources.info_512;
            this.pb3.Location = new System.Drawing.Point(784, 520);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(23, 23);
            this.pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb3.TabIndex = 77;
            this.pb3.TabStop = false;
            // 
            // pb6
            // 
            this.pb6.Image = global::mandc_Assign4.Properties.Resources.info_512;
            this.pb6.Location = new System.Drawing.Point(754, 591);
            this.pb6.Name = "pb6";
            this.pb6.Size = new System.Drawing.Size(23, 23);
            this.pb6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb6.TabIndex = 78;
            this.pb6.TabStop = false;
            // 
            // pb4
            // 
            this.pb4.Image = global::mandc_Assign4.Properties.Resources.info_512;
            this.pb4.Location = new System.Drawing.Point(234, 596);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(23, 23);
            this.pb4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb4.TabIndex = 79;
            this.pb4.TabStop = false;
            // 
            // toolTip1
            // 
            this.toolTip1.BackColor = System.Drawing.Color.Gray;
            this.toolTip1.ForeColor = System.Drawing.SystemColors.HighlightText;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(819, 631);
            this.Controls.Add(this.pb4);
            this.Controls.Add(this.pb6);
            this.Controls.Add(this.pb3);
            this.Controls.Add(this.pb2);
            this.Controls.Add(this.pb1);
            this.Controls.Add(this.pb5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.rTxt);
            this.Controls.Add(this.kTxt);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.hTxt);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.d2Txt);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.color4);
            this.Controls.Add(this.color3);
            this.Controls.Add(this.color2);
            this.Controls.Add(this.color1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnGraph);
            this.Controls.Add(this.c2Txt);
            this.Controls.Add(this.a2Txt);
            this.Controls.Add(this.b2Txt);
            this.Controls.Add(this.c1Txt);
            this.Controls.Add(this.b1Txt);
            this.Controls.Add(this.a1Txt);
            this.Controls.Add(this.bTxt);
            this.Controls.Add(this.mTxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnAxis);
            this.Controls.Add(this.lblyInterval);
            this.Controls.Add(this.lblyMax);
            this.Controls.Add(this.lblyMin);
            this.Controls.Add(this.lblxInterval);
            this.Controls.Add(this.lblxMax);
            this.Controls.Add(this.lblxMin);
            this.Controls.Add(this.yIntervalTxt);
            this.Controls.Add(this.yMaxTxt);
            this.Controls.Add(this.yMinTxt);
            this.Controls.Add(this.xIntervalTxt);
            this.Controls.Add(this.xMaxTxt);
            this.Controls.Add(this.xMinTxt);
            this.Controls.Add(this.graph);
            this.Name = "Form1";
            this.ShowInTaskbar = false;
            this.Text = "Graphing Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.graph)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox graph;
        private System.Windows.Forms.TextBox xMinTxt;
        private System.Windows.Forms.TextBox xMaxTxt;
        private System.Windows.Forms.TextBox xIntervalTxt;
        private System.Windows.Forms.TextBox yMinTxt;
        private System.Windows.Forms.TextBox yMaxTxt;
        private System.Windows.Forms.TextBox yIntervalTxt;
        private System.Windows.Forms.Label lblxMin;
        private System.Windows.Forms.Label lblxMax;
        private System.Windows.Forms.Label lblxInterval;
        private System.Windows.Forms.Label lblyMin;
        private System.Windows.Forms.Label lblyMax;
        private System.Windows.Forms.Label lblyInterval;
        private System.Windows.Forms.Button btnAxis;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox mTxt;
        private System.Windows.Forms.TextBox bTxt;
        private System.Windows.Forms.TextBox a1Txt;
        private System.Windows.Forms.TextBox b1Txt;
        private System.Windows.Forms.TextBox c1Txt;
        private System.Windows.Forms.TextBox b2Txt;
        private System.Windows.Forms.TextBox a2Txt;
        private System.Windows.Forms.TextBox c2Txt;
        private System.Windows.Forms.TextBox d2Txt;
        private System.Windows.Forms.TextBox hTxt;
        private System.Windows.Forms.TextBox kTxt;
        private System.Windows.Forms.TextBox rTxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnGraph;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button color1;
        private System.Windows.Forms.Button color2;
        private System.Windows.Forms.Button color3;
        private System.Windows.Forms.Button color4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.PictureBox pb5;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.PictureBox pb3;
        private System.Windows.Forms.PictureBox pb6;
        private System.Windows.Forms.PictureBox pb4;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

