﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace mandc_Assign6
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            ChartArea chartArea2 = new ChartArea();
            Legend legend2 = new Legend();
            Series series2 = new Series();
            string line = "";
            string[] tokens;
            DataPoint[] array = new DataPoint[11];
            int i = 0;
            //read in input file
            using (StreamReader inFile = new StreamReader("..\\..\\data4.txt"))
            {
                line = inFile.ReadLine();
                while (line != null)
                {
                    tokens = line.Split();
                    DataPoint d = new DataPoint(Convert.ToDouble(tokens[0]), Convert.ToDouble(tokens[1])); //create data point
                    d.Color = Color.Black;
                    array[i] = d; //add data point to array
                    i++;
                    line = inFile.ReadLine();

                }
            }

            Title title2 = new Title();
            Chart chart1 = new Chart();

            //various chart attributes
            chartArea2.AxisX.Title = "Age (in years)";
            chartArea2.AxisY.Title = "Amount of Laughter (in percentage)";
            chartArea2.Name = "ChartArea1";
            chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            legend2.Title = "Gender";
            chart1.Legends.Add(legend2);
            chart1.Location = new System.Drawing.Point(24, 17);
            chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series2.Legend = "Legend1";
            series2.LegendText = "Males";
            series2.MarkerColor = System.Drawing.Color.Black;
            series2.Name = "Series1";

            for (int j = 0; j < 11; j++)
                series2.Points.Add(array[j]);
     
            chart1.Series.Add(series2);
            chart1.Size = new System.Drawing.Size(591, 300);
            chart1.TabIndex = 3;
            chart1.Text = "chart1";
            title2.Name = "Title1";
            title2.Text = "How Funny Farts Are by Age";
            chart1.Titles.Add(title2);

            Controls.Add(chart1);
        }

        /***************************************************************
        private void Form4_FormClosed(object sender, FormClosedEventArgs e)

        Use: Closes the form and displays the portal 

        Parameters: object sender - the object being called
                    FormClosedEventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/

        private void Form4_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }

        /***************************************************************
        private void button1_Click(object sender, EventArgs e)

        Use: Hides the current form and displays the Portal form

        Parameters: object sender - the object being called
                    EventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }
    }
}
