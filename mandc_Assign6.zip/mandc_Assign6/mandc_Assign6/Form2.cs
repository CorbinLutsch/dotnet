﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace mandc_Assign6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            ChartArea chartArea1 = new ChartArea();
            Legend legend1 = new Legend();
            Series series1 = new Series();

            string line = "";
            string[] tokens;
            DataPoint[] array = new DataPoint[33];
            int i = 0;
            //read the input file and create data points
            using (StreamReader inFile = new StreamReader("..\\..\\data2.txt"))
            {
                line = inFile.ReadLine();
                while (line != null)
                {
                    tokens = line.Split();
                    DataPoint d = new DataPoint(Convert.ToDouble(tokens[0]), Convert.ToDouble(tokens[1]));
                    array[i] = d; //add data point to the array
                    i++;
                    line = inFile.ReadLine();
                }
            }
  
            
            Series series2 = new Series();
            Series series3 = new Series();
            Title title1 = new Title();
            Chart chart1 = new Chart();

            //various attributes of the chart
            chartArea1.AxisX.Title = "Time (in years)";
            chartArea1.AxisY.Title = "Weight (in lbs)";
            chartArea1.Name = "ChartArea1";
            chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            legend1.Title = "Race";
            chart1.Legends.Add(legend1);
            chart1.Location = new System.Drawing.Point(12, 12);
            chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Color = System.Drawing.Color.Aqua;
            series1.Legend = "Legend1";
            series1.LegendText = "Alien";
            series1.Name = "Series1";

            for (int j = 0; j < 11; j++) //add the first series
                series1.Points.Add(array[j]);

            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Color = System.Drawing.Color.BlueViolet;
            series2.Legend = "Legend1";
            series2.LegendText = "Zombie";
            series2.Name = "Series2";

            for (int j = 11; j < 22; j++) //second series
                series2.Points.Add(array[j]);

            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Color = System.Drawing.Color.Red;
            series3.Legend = "Legend1";
            series3.LegendText = "Human";
            series3.Name = "Series3";

            for (int j = 22; j < 33; j++) //third series
                series3.Points.Add(array[j]);
    
            chart1.Series.Add(series1); //add the series to the chart
            chart1.Series.Add(series2);
            chart1.Series.Add(series3);
            chart1.Size = new System.Drawing.Size(579, 300);
            chart1.TabIndex = 1;
            chart1.Text = "chart1";
            title1.Name = "Title1";
            title1.Text = "Weight by Race";
            chart1.Titles.Add(title1);

            Controls.Add(chart1);
        }

        /***************************************************************
        private void button1_Click(object sender, EventArgs e)

        Use: Hides the current form and displays the Portal form
     
        Parameters: object sender - the object being called
                    EventArgs e - the event that takes place
			
        Returns: nothing
        ***************************************************************/
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }

        /***************************************************************
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)

        Use: Closes the form and displays the portal 

        Parameters: object sender - the object being called
                    FormClosedEventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }
    }
}
