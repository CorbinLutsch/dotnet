﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace mandc_Assign6
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            ChartArea chartArea1 = new ChartArea();
            Legend legend1 = new Legend();
            Series series1 = new Series();

            string line = "";
            string[] tokens;
            DataPoint[] array = new DataPoint[12];
            int i = 0;
            //read in the data from out input file 
            using (StreamReader inFile = new StreamReader("..\\..\\data3.txt"))
            {
                line = inFile.ReadLine();
                while (line != null)
                {
                    tokens = line.Split();
                    DataPoint d = new DataPoint(Convert.ToDouble(tokens[0]), Convert.ToDouble(tokens[1])); //create data point
                    d.Color = Color.Orange; 
                    array[i] = d; //add to our array
                    i++;
                    line = inFile.ReadLine();
                    
                }
            }
   
            Title title1 = new Title();

            //various chart attributes 
            Chart chart1 = new Chart();
            chartArea1.AxisX.Title = "Age (in years)";
            chartArea1.AxisY.Title = "Number of Cats Owned";
            chartArea1.Name = "ChartArea1";
            chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            legend1.Title = "Gender";
            chart1.Legends.Add(legend1);
            chart1.Location = new System.Drawing.Point(12, 24);
            chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Color = System.Drawing.Color.Orange;
            series1.Legend = "Legend1";
            series1.LegendText = "Females";
            series1.Name = "Series1";

            for (int j = 0; j < 12; j++) //add the points to the series
                series1.Points.Add(array[j]);

            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            chart1.Series.Add(series1);
            chart1.Size = new System.Drawing.Size(556, 283);
            chart1.TabIndex = 2;
            chart1.Text = "chart1";
            title1.Name = "Title1";
            title1.Text = "Number of Cats Owned by Age";
            chart1.Titles.Add(title1);

            Controls.Add(chart1);

        }

        public object DataPoints { get; }

      /***************************************************************
      private void button1_Click(object sender, EventArgs e)

      Use: Hides the current form and displays the Portal form

      Parameters: object sender - the object being called
                  EventArgs e - the event that takes place

      Returns: nothing
      ***************************************************************/
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }

        /***************************************************************
        private void Form3_FormClosed(object sender, FormClosedEventArgs e)

        Use: Closes the form and displays the portal 

        Parameters: object sender - the object being called
                    FormClosedEventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }
    }
}
