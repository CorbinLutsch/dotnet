﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace mandc_Assign6
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            ChartArea chartArea3 = new ChartArea();
            Legend legend3 = new Legend();
            Series series3 = new Series();

            string line = "";
            string[] tokens;
            DataPoint[] array = new DataPoint[11];
            int i = 0;
            //read input file
            using (StreamReader inFile = new StreamReader("..\\..\\data5.txt"))
            {
                line = inFile.ReadLine();
                while (line != null)
                {
                    tokens = line.Split();
                    DataPoint d = new DataPoint(Convert.ToDouble(tokens[0]), Convert.ToDouble(tokens[1])); //create data point
                    d.Color = Color.Purple;
                    array[i] = d; //add data point to array
                    i++;
                    line = inFile.ReadLine();

                }
            }
 
            Title title3 = new Title();

            Chart chart1 = new Chart();

            //various chart attributes
            chartArea3.AxisX.Title = "Length (in seconds)";
            chartArea3.AxisY.Title = "Frequency (in Hertz)";
            chartArea3.Name = "ChartArea1";
            chart1.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            legend3.Title = "Gender";
            chart1.Legends.Add(legend3);
            chart1.Location = new System.Drawing.Point(12, 12);
            chart1.Name = "chart1";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Legend = "Legend1";
            series3.LegendText = "Females";
            series3.Name = "Series1";
            series3.Color = Color.Purple;

            for (int j = 0; j < 11; j++)
                series3.Points.Add(array[j]); //add data points to series
    
            chart1.Series.Add(series3);
            chart1.Size = new System.Drawing.Size(620, 311);
            chart1.TabIndex = 3;
            chart1.Text = "chart1";
            title3.Name = "Title1";
            title3.Text = "Frequency of Farts ";
            chart1.Titles.Add(title3);

            Controls.Add(chart1);

        }

        /***************************************************************
        private void Form5_FormClosed(object sender, FormClosedEventArgs e)

        Use: Closes the form and displays the portal 

        Parameters: object sender - the object being called
                    FormClosedEventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }

        /***************************************************************
        private void button1_Click(object sender, EventArgs e)

        Use: Hides the current form and displays the Portal form

        Parameters: object sender - the object being called
                    EventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formToShow = Application.OpenForms.Cast<Form>().FirstOrDefault(c => c is Form1);
            if (formToShow != null)
            {
                formToShow.Show();
            }
        }
    }
}
