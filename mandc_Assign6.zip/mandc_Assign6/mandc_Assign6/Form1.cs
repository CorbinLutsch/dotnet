﻿/* Corbin Lutsch & Matthew Lord
 *     Z1837389  & Z1848456
 *  CSCI - 473
 *  Due: 04/25/19
 *  Assignment 6 - Uncharted 
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mandc_Assign6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        /***************************************************************
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)

        Use: Closes all forms by calling Application.Exit()

        Parameters: object sender - the object being called
                    FormClosedEventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        /***************************************************************
        private void btn1_Click(object sender, EventArgs e)

        Use: Displays the first chart, Form2

        Parameters: object sender - the object being called
                    FormClosedEventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void btn1_Click(object sender, EventArgs e)
        {
            (new Form2()).Show(); this.Hide();
        }

        /***************************************************************
       private void btn2_Click(object sender, EventArgs e)

       Use: Displays the second chart, Form3

       Parameters: object sender - the object being called
                   FormClosedEventArgs e - the event that takes place

       Returns: nothing
       ***************************************************************/
        private void btn2_Click(object sender, EventArgs e)
        {
            (new Form3()).Show(); this.Hide();
        }

        /***************************************************************
       private void btn1_Click(object sender, EventArgs e)

       Use: Displays the third chart, Form4

       Parameters: object sender - the object being called
                   FormClosedEventArgs e - the event that takes place

       Returns: nothing
       ***************************************************************/
        private void btn3_Click(object sender, EventArgs e)
        {
            (new Form4()).Show(); this.Hide();
        }

        /***************************************************************
       private void btn4_Click(object sender, EventArgs e)

       Use: Displays the fourth chart, Form5

       Parameters: object sender - the object being called
                   FormClosedEventArgs e - the event that takes place

       Returns: nothing
       ***************************************************************/
        private void btn4_Click(object sender, EventArgs e)
        {
            (new Form5()).Show(); this.Hide();
        }

        /***************************************************************
        private void btnExit_Click(object sender, EventArgs e)

        Use: Closes all forms by calling Application.Exit()

        Parameters: object sender - the object being called
                    FormClosedEventArgs e - the event that takes place

        Returns: nothing
        ***************************************************************/
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
