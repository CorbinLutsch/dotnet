﻿namespace mandc_Assign3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btnClassTypes = new System.Windows.Forms.Button();
            this.btnPercentRace = new System.Windows.Forms.Button();
            this.btnRoleTypes = new System.Windows.Forms.Button();
            this.btnGuildTypes = new System.Windows.Forms.Button();
            this.btnFillRole = new System.Windows.Forms.Button();
            this.btnMaxLevel = new System.Windows.Forms.Button();
            this.cbClass = new System.Windows.Forms.ComboBox();
            this.cbServer1 = new System.Windows.Forms.ComboBox();
            this.cbServer2 = new System.Windows.Forms.ComboBox();
            this.cbRole = new System.Windows.Forms.ComboBox();
            this.cbServer3 = new System.Windows.Forms.ComboBox();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioDamage = new System.Windows.Forms.RadioButton();
            this.radioHealer = new System.Windows.Forms.RadioButton();
            this.radioTank = new System.Windows.Forms.RadioButton();
            this.min = new System.Windows.Forms.NumericUpDown();
            this.max = new System.Windows.Forms.NumericUpDown();
            this.rTextBox = new System.Windows.Forms.RichTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.max)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(36, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "All Class Type from a Single Server";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(39, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Class";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(180, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Server";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(46, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Role";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(180, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Server";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(180, 185);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Server";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(46, 238);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "Min";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(137, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 18);
            this.label8.TabIndex = 7;
            this.label8.Text = "Max";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(42, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 18);
            this.label9.TabIndex = 8;
            this.label9.Text = "Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(36, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(335, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Percentage of Each Race From a Single Server";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(39, 169);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(407, 16);
            this.label11.TabIndex = 10;
            this.label11.Text = "All Role Types from a Single Server Within a Level Range";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(39, 302);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(192, 16);
            this.label12.TabIndex = 11;
            this.label12.Text = "All Guilds of a Single Type";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(36, 384);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(376, 16);
            this.label13.TabIndex = 12;
            this.label13.Text = "All Players Who Could Fill a Role But Presently Aren\'t";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(36, 512);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(322, 16);
            this.label14.TabIndex = 13;
            this.label14.Text = "Percentage of Max Level Players in All Guilds";
            // 
            // btnClassTypes
            // 
            this.btnClassTypes.Location = new System.Drawing.Point(353, 58);
            this.btnClassTypes.Name = "btnClassTypes";
            this.btnClassTypes.Size = new System.Drawing.Size(90, 23);
            this.btnClassTypes.TabIndex = 14;
            this.btnClassTypes.Text = "Show Results";
            this.btnClassTypes.UseVisualStyleBackColor = true;
            this.btnClassTypes.Click += new System.EventHandler(this.Button_Class_Types);
            // 
            // btnPercentRace
            // 
            this.btnPercentRace.Location = new System.Drawing.Point(353, 128);
            this.btnPercentRace.Name = "btnPercentRace";
            this.btnPercentRace.Size = new System.Drawing.Size(90, 23);
            this.btnPercentRace.TabIndex = 15;
            this.btnPercentRace.Text = "Show Results";
            this.btnPercentRace.UseVisualStyleBackColor = true;
            this.btnPercentRace.Click += new System.EventHandler(this.Button_Role_Percent);
            // 
            // btnRoleTypes
            // 
            this.btnRoleTypes.Location = new System.Drawing.Point(353, 206);
            this.btnRoleTypes.Name = "btnRoleTypes";
            this.btnRoleTypes.Size = new System.Drawing.Size(90, 23);
            this.btnRoleTypes.TabIndex = 16;
            this.btnRoleTypes.Text = "Show Results";
            this.btnRoleTypes.UseVisualStyleBackColor = true;
            this.btnRoleTypes.Click += new System.EventHandler(this.Button_Roles_Server_Range);
            // 
            // btnGuildTypes
            // 
            this.btnGuildTypes.Location = new System.Drawing.Point(356, 337);
            this.btnGuildTypes.Name = "btnGuildTypes";
            this.btnGuildTypes.Size = new System.Drawing.Size(90, 23);
            this.btnGuildTypes.TabIndex = 17;
            this.btnGuildTypes.Text = "Show Results";
            this.btnGuildTypes.UseVisualStyleBackColor = true;
            this.btnGuildTypes.Click += new System.EventHandler(this.Button_Guild_Types);
            // 
            // btnFillRole
            // 
            this.btnFillRole.Location = new System.Drawing.Point(353, 414);
            this.btnFillRole.Name = "btnFillRole";
            this.btnFillRole.Size = new System.Drawing.Size(90, 23);
            this.btnFillRole.TabIndex = 18;
            this.btnFillRole.Text = "Show Results";
            this.btnFillRole.UseVisualStyleBackColor = true;
            this.btnFillRole.Click += new System.EventHandler(this.Button_Not_In_Role);
            // 
            // btnMaxLevel
            // 
            this.btnMaxLevel.Location = new System.Drawing.Point(353, 542);
            this.btnMaxLevel.Name = "btnMaxLevel";
            this.btnMaxLevel.Size = new System.Drawing.Size(90, 23);
            this.btnMaxLevel.TabIndex = 19;
            this.btnMaxLevel.Text = "Show Results";
            this.btnMaxLevel.UseVisualStyleBackColor = true;
            this.btnMaxLevel.Click += new System.EventHandler(this.Button_Max_Level);
            // 
            // cbClass
            // 
            this.cbClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbClass.FormattingEnabled = true;
            this.cbClass.Location = new System.Drawing.Point(42, 60);
            this.cbClass.Name = "cbClass";
            this.cbClass.Size = new System.Drawing.Size(121, 21);
            this.cbClass.TabIndex = 20;
            // 
            // cbServer1
            // 
            this.cbServer1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbServer1.FormattingEnabled = true;
            this.cbServer1.Location = new System.Drawing.Point(183, 60);
            this.cbServer1.Name = "cbServer1";
            this.cbServer1.Size = new System.Drawing.Size(121, 21);
            this.cbServer1.TabIndex = 21;
            // 
            // cbServer2
            // 
            this.cbServer2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbServer2.FormattingEnabled = true;
            this.cbServer2.Location = new System.Drawing.Point(183, 128);
            this.cbServer2.Name = "cbServer2";
            this.cbServer2.Size = new System.Drawing.Size(121, 21);
            this.cbServer2.TabIndex = 22;
            // 
            // cbRole
            // 
            this.cbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRole.FormattingEnabled = true;
            this.cbRole.Location = new System.Drawing.Point(49, 206);
            this.cbRole.Name = "cbRole";
            this.cbRole.Size = new System.Drawing.Size(121, 21);
            this.cbRole.TabIndex = 23;
            // 
            // cbServer3
            // 
            this.cbServer3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbServer3.FormattingEnabled = true;
            this.cbServer3.Location = new System.Drawing.Point(183, 206);
            this.cbServer3.Name = "cbServer3";
            this.cbServer3.Size = new System.Drawing.Size(121, 21);
            this.cbServer3.TabIndex = 24;
            // 
            // cbType
            // 
            this.cbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbType.FormattingEnabled = true;
            this.cbType.Location = new System.Drawing.Point(45, 339);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(121, 21);
            this.cbType.TabIndex = 25;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioDamage);
            this.groupBox1.Controls.Add(this.radioHealer);
            this.groupBox1.Controls.Add(this.radioTank);
            this.groupBox1.Location = new System.Drawing.Point(42, 414);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(212, 59);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // radioDamage
            // 
            this.radioDamage.AutoSize = true;
            this.radioDamage.ForeColor = System.Drawing.Color.White;
            this.radioDamage.Location = new System.Drawing.Point(127, 21);
            this.radioDamage.Name = "radioDamage";
            this.radioDamage.Size = new System.Drawing.Size(65, 17);
            this.radioDamage.TabIndex = 2;
            this.radioDamage.Text = "Damage";
            this.radioDamage.UseVisualStyleBackColor = true;
            // 
            // radioHealer
            // 
            this.radioHealer.AutoSize = true;
            this.radioHealer.ForeColor = System.Drawing.Color.White;
            this.radioHealer.Location = new System.Drawing.Point(65, 21);
            this.radioHealer.Name = "radioHealer";
            this.radioHealer.Size = new System.Drawing.Size(56, 17);
            this.radioHealer.TabIndex = 1;
            this.radioHealer.Text = "Healer";
            this.radioHealer.UseVisualStyleBackColor = true;
            // 
            // radioTank
            // 
            this.radioTank.AutoSize = true;
            this.radioTank.ForeColor = System.Drawing.Color.White;
            this.radioTank.Location = new System.Drawing.Point(7, 20);
            this.radioTank.Name = "radioTank";
            this.radioTank.Size = new System.Drawing.Size(50, 17);
            this.radioTank.TabIndex = 0;
            this.radioTank.Text = "Tank";
            this.radioTank.UseVisualStyleBackColor = true;
            // 
            // min
            // 
            this.min.Location = new System.Drawing.Point(49, 260);
            this.min.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.min.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(36, 20);
            this.min.TabIndex = 27;
            this.min.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.min.ValueChanged += new System.EventHandler(this.Min_Value_Changed);
            // 
            // max
            // 
            this.max.Location = new System.Drawing.Point(140, 260);
            this.max.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.max.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.max.Name = "max";
            this.max.Size = new System.Drawing.Size(36, 20);
            this.max.TabIndex = 28;
            this.max.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.max.ValueChanged += new System.EventHandler(this.Max_Value_Changed);
            // 
            // rTextBox
            // 
            this.rTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.rTextBox.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rTextBox.Location = new System.Drawing.Point(494, 39);
            this.rTextBox.Name = "rTextBox";
            this.rTextBox.Size = new System.Drawing.Size(731, 526);
            this.rTextBox.TabIndex = 29;
            this.rTextBox.Text = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(629, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 25);
            this.label15.TabIndex = 30;
            this.label15.Text = "Query";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1237, 590);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.rTextBox);
            this.Controls.Add(this.max);
            this.Controls.Add(this.min);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.cbServer3);
            this.Controls.Add(this.cbRole);
            this.Controls.Add(this.cbServer2);
            this.Controls.Add(this.cbServer1);
            this.Controls.Add(this.cbClass);
            this.Controls.Add(this.btnMaxLevel);
            this.Controls.Add(this.btnFillRole);
            this.Controls.Add(this.btnGuildTypes);
            this.Controls.Add(this.btnRoleTypes);
            this.Controls.Add(this.btnPercentRace);
            this.Controls.Add(this.btnClassTypes);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "World of ConflictCraft: Querying System";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.max)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnClassTypes;
        private System.Windows.Forms.Button btnPercentRace;
        private System.Windows.Forms.Button btnRoleTypes;
        private System.Windows.Forms.Button btnGuildTypes;
        private System.Windows.Forms.Button btnFillRole;
        private System.Windows.Forms.Button btnMaxLevel;
        private System.Windows.Forms.ComboBox cbClass;
        private System.Windows.Forms.ComboBox cbServer1;
        private System.Windows.Forms.ComboBox cbServer2;
        private System.Windows.Forms.ComboBox cbRole;
        private System.Windows.Forms.ComboBox cbServer3;
        private System.Windows.Forms.ComboBox cbType;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioDamage;
        private System.Windows.Forms.RadioButton radioHealer;
        private System.Windows.Forms.RadioButton radioTank;
        private System.Windows.Forms.NumericUpDown min;
        private System.Windows.Forms.NumericUpDown max;
        private System.Windows.Forms.RichTextBox rTextBox;
        private System.Windows.Forms.Label label15;
    }
}

