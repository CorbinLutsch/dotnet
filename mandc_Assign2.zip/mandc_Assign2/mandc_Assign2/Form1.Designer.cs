﻿namespace mandc_Assign2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSearchGuild = new System.Windows.Forms.Label();
            this.lblSearchPlayer = new System.Windows.Forms.Label();
            this.txtSearchServer = new System.Windows.Forms.TextBox();
            this.txtSearchPlayer = new System.Windows.Forms.TextBox();
            this.btnApplySearch = new System.Windows.Forms.Button();
            this.btnLeaveGuild = new System.Windows.Forms.Button();
            this.btnJoinGuild = new System.Windows.Forms.Button();
            this.btnDisbandGuild = new System.Windows.Forms.Button();
            this.btnPrintGuild = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblClass = new System.Windows.Forms.Label();
            this.lblRace = new System.Windows.Forms.Label();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.btnAddPlayer = new System.Windows.Forms.Button();
            this.cbRole = new System.Windows.Forms.ComboBox();
            this.cbClass = new System.Windows.Forms.ComboBox();
            this.cbRace = new System.Windows.Forms.ComboBox();
            this.txtPlayerName = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAddGuild = new System.Windows.Forms.Button();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.cbServer = new System.Windows.Forms.ComboBox();
            this.txtGuildName = new System.Windows.Forms.TextBox();
            this.lblSystem = new System.Windows.Forms.Label();
            this.lblPlayers = new System.Windows.Forms.Label();
            this.lblGuilds = new System.Windows.Forms.Label();
            this.lblO = new System.Windows.Forms.Label();
            this.lsBoxPlayers = new System.Windows.Forms.ListBox();
            this.lsBoxGuilds = new System.Windows.Forms.ListBox();
            this.rTextBox = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Controls.Add(this.lblSearchGuild);
            this.groupBox1.Controls.Add(this.lblSearchPlayer);
            this.groupBox1.Controls.Add(this.txtSearchServer);
            this.groupBox1.Controls.Add(this.txtSearchPlayer);
            this.groupBox1.Controls.Add(this.btnApplySearch);
            this.groupBox1.Controls.Add(this.btnLeaveGuild);
            this.groupBox1.Controls.Add(this.btnJoinGuild);
            this.groupBox1.Controls.Add(this.btnDisbandGuild);
            this.groupBox1.Controls.Add(this.btnPrintGuild);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(44, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 174);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Management Functions";
            // 
            // lblSearchGuild
            // 
            this.lblSearchGuild.AutoSize = true;
            this.lblSearchGuild.Location = new System.Drawing.Point(140, 73);
            this.lblSearchGuild.Name = "lblSearchGuild";
            this.lblSearchGuild.Size = new System.Drawing.Size(122, 13);
            this.lblSearchGuild.TabIndex = 8;
            this.lblSearchGuild.Text = "Search Guild (by Server)";
            // 
            // lblSearchPlayer
            // 
            this.lblSearchPlayer.AutoSize = true;
            this.lblSearchPlayer.Location = new System.Drawing.Point(140, 24);
            this.lblSearchPlayer.Name = "lblSearchPlayer";
            this.lblSearchPlayer.Size = new System.Drawing.Size(124, 13);
            this.lblSearchPlayer.TabIndex = 7;
            this.lblSearchPlayer.Text = "Search Player (by Name)";
            // 
            // txtSearchServer
            // 
            this.txtSearchServer.Location = new System.Drawing.Point(143, 89);
            this.txtSearchServer.Name = "txtSearchServer";
            this.txtSearchServer.Size = new System.Drawing.Size(137, 20);
            this.txtSearchServer.TabIndex = 6;
            // 
            // txtSearchPlayer
            // 
            this.txtSearchPlayer.Location = new System.Drawing.Point(143, 40);
            this.txtSearchPlayer.Name = "txtSearchPlayer";
            this.txtSearchPlayer.Size = new System.Drawing.Size(137, 20);
            this.txtSearchPlayer.TabIndex = 5;
            // 
            // btnApplySearch
            // 
            this.btnApplySearch.ForeColor = System.Drawing.Color.Black;
            this.btnApplySearch.Location = new System.Drawing.Point(16, 135);
            this.btnApplySearch.Name = "btnApplySearch";
            this.btnApplySearch.Size = new System.Drawing.Size(104, 23);
            this.btnApplySearch.TabIndex = 4;
            this.btnApplySearch.Text = "Apply Search Criteria";
            this.btnApplySearch.UseVisualStyleBackColor = true;
            this.btnApplySearch.Click += new System.EventHandler(this.Button_Apply_Search);
            // 
            // btnLeaveGuild
            // 
            this.btnLeaveGuild.ForeColor = System.Drawing.Color.Black;
            this.btnLeaveGuild.Location = new System.Drawing.Point(16, 106);
            this.btnLeaveGuild.Name = "btnLeaveGuild";
            this.btnLeaveGuild.Size = new System.Drawing.Size(104, 23);
            this.btnLeaveGuild.TabIndex = 3;
            this.btnLeaveGuild.Text = "Leave Guild";
            this.btnLeaveGuild.UseVisualStyleBackColor = true;
            this.btnLeaveGuild.Click += new System.EventHandler(this.Button_Leave_Guild);
            // 
            // btnJoinGuild
            // 
            this.btnJoinGuild.ForeColor = System.Drawing.Color.Black;
            this.btnJoinGuild.Location = new System.Drawing.Point(16, 77);
            this.btnJoinGuild.Name = "btnJoinGuild";
            this.btnJoinGuild.Size = new System.Drawing.Size(104, 23);
            this.btnJoinGuild.TabIndex = 2;
            this.btnJoinGuild.Text = "Join Guild";
            this.btnJoinGuild.UseVisualStyleBackColor = true;
            this.btnJoinGuild.Click += new System.EventHandler(this.Button_Join_Guild);
            // 
            // btnDisbandGuild
            // 
            this.btnDisbandGuild.ForeColor = System.Drawing.Color.Black;
            this.btnDisbandGuild.Location = new System.Drawing.Point(16, 48);
            this.btnDisbandGuild.Name = "btnDisbandGuild";
            this.btnDisbandGuild.Size = new System.Drawing.Size(104, 23);
            this.btnDisbandGuild.TabIndex = 1;
            this.btnDisbandGuild.Text = "Disband Guild";
            this.btnDisbandGuild.UseVisualStyleBackColor = true;
            this.btnDisbandGuild.Click += new System.EventHandler(this.Button_Disband_Guild);
            // 
            // btnPrintGuild
            // 
            this.btnPrintGuild.ForeColor = System.Drawing.Color.Black;
            this.btnPrintGuild.Location = new System.Drawing.Point(16, 19);
            this.btnPrintGuild.Name = "btnPrintGuild";
            this.btnPrintGuild.Size = new System.Drawing.Size(104, 23);
            this.btnPrintGuild.TabIndex = 0;
            this.btnPrintGuild.Text = "Print Guild Roster";
            this.btnPrintGuild.UseVisualStyleBackColor = true;
            this.btnPrintGuild.Click += new System.EventHandler(this.Button_Print_Guild);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblRole);
            this.groupBox2.Controls.Add(this.lblClass);
            this.groupBox2.Controls.Add(this.lblRace);
            this.groupBox2.Controls.Add(this.lblPlayerName);
            this.groupBox2.Controls.Add(this.btnAddPlayer);
            this.groupBox2.Controls.Add(this.cbRole);
            this.groupBox2.Controls.Add(this.cbClass);
            this.groupBox2.Controls.Add(this.cbRace);
            this.groupBox2.Controls.Add(this.txtPlayerName);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(44, 192);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(396, 142);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Create New Player";
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(156, 78);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(29, 13);
            this.lblRole.TabIndex = 8;
            this.lblRole.Text = "Role";
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Location = new System.Drawing.Point(16, 78);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(32, 13);
            this.lblClass.TabIndex = 7;
            this.lblClass.Text = "Class";
            // 
            // lblRace
            // 
            this.lblRace.AutoSize = true;
            this.lblRace.Location = new System.Drawing.Point(158, 28);
            this.lblRace.Name = "lblRace";
            this.lblRace.Size = new System.Drawing.Size(33, 13);
            this.lblRace.TabIndex = 6;
            this.lblRace.Text = "Race";
            // 
            // lblPlayerName
            // 
            this.lblPlayerName.AutoSize = true;
            this.lblPlayerName.Location = new System.Drawing.Point(13, 29);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(67, 13);
            this.lblPlayerName.TabIndex = 5;
            this.lblPlayerName.Text = "Player Name";
            // 
            // btnAddPlayer
            // 
            this.btnAddPlayer.BackColor = System.Drawing.Color.Transparent;
            this.btnAddPlayer.ForeColor = System.Drawing.Color.Black;
            this.btnAddPlayer.Location = new System.Drawing.Point(294, 41);
            this.btnAddPlayer.Name = "btnAddPlayer";
            this.btnAddPlayer.Size = new System.Drawing.Size(96, 24);
            this.btnAddPlayer.TabIndex = 4;
            this.btnAddPlayer.Text = "Add Player";
            this.btnAddPlayer.UseVisualStyleBackColor = false;
            this.btnAddPlayer.Click += new System.EventHandler(this.Button_Add_Player);
            // 
            // cbRole
            // 
            this.cbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRole.FormattingEnabled = true;
            this.cbRole.Location = new System.Drawing.Point(159, 94);
            this.cbRole.Name = "cbRole";
            this.cbRole.Size = new System.Drawing.Size(121, 21);
            this.cbRole.TabIndex = 3;
            // 
            // cbClass
            // 
            this.cbClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbClass.FormattingEnabled = true;
            this.cbClass.Location = new System.Drawing.Point(16, 94);
            this.cbClass.Name = "cbClass";
            this.cbClass.Size = new System.Drawing.Size(121, 21);
            this.cbClass.TabIndex = 2;
            this.cbClass.SelectedIndexChanged += new System.EventHandler(this.cbClass_SelectedIndexChanged);
            // 
            // cbRace
            // 
            this.cbRace.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRace.FormattingEnabled = true;
            this.cbRace.Location = new System.Drawing.Point(159, 44);
            this.cbRace.Name = "cbRace";
            this.cbRace.Size = new System.Drawing.Size(121, 21);
            this.cbRace.TabIndex = 1;
            // 
            // txtPlayerName
            // 
            this.txtPlayerName.Location = new System.Drawing.Point(16, 45);
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Size = new System.Drawing.Size(121, 20);
            this.txtPlayerName.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.btnAddGuild);
            this.groupBox3.Controls.Add(this.cbType);
            this.groupBox3.Controls.Add(this.cbServer);
            this.groupBox3.Controls.Add(this.txtGuildName);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(44, 340);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(396, 146);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Create New Guild";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(160, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(160, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Server";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Guild Name";
            // 
            // btnAddGuild
            // 
            this.btnAddGuild.ForeColor = System.Drawing.Color.Black;
            this.btnAddGuild.Location = new System.Drawing.Point(294, 45);
            this.btnAddGuild.Name = "btnAddGuild";
            this.btnAddGuild.Size = new System.Drawing.Size(88, 23);
            this.btnAddGuild.TabIndex = 3;
            this.btnAddGuild.Text = "Add Guild";
            this.btnAddGuild.UseVisualStyleBackColor = true;
            this.btnAddGuild.Click += new System.EventHandler(this.Button_Add_Guild);
            // 
            // cbType
            // 
            this.cbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbType.FormattingEnabled = true;
            this.cbType.Location = new System.Drawing.Point(159, 97);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(121, 21);
            this.cbType.TabIndex = 2;
            // 
            // cbServer
            // 
            this.cbServer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbServer.FormattingEnabled = true;
            this.cbServer.Location = new System.Drawing.Point(159, 47);
            this.cbServer.Name = "cbServer";
            this.cbServer.Size = new System.Drawing.Size(121, 21);
            this.cbServer.TabIndex = 1;
            // 
            // txtGuildName
            // 
            this.txtGuildName.Location = new System.Drawing.Point(9, 48);
            this.txtGuildName.Name = "txtGuildName";
            this.txtGuildName.Size = new System.Drawing.Size(121, 20);
            this.txtGuildName.TabIndex = 0;
            // 
            // lblSystem
            // 
            this.lblSystem.AutoSize = true;
            this.lblSystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSystem.ForeColor = System.Drawing.Color.White;
            this.lblSystem.Location = new System.Drawing.Point(556, 12);
            this.lblSystem.Name = "lblSystem";
            this.lblSystem.Size = new System.Drawing.Size(424, 31);
            this.lblSystem.TabIndex = 3;
            this.lblSystem.Text = "Player/Guild Management System";
            // 
            // lblPlayers
            // 
            this.lblPlayers.AutoSize = true;
            this.lblPlayers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayers.ForeColor = System.Drawing.Color.White;
            this.lblPlayers.Location = new System.Drawing.Point(470, 50);
            this.lblPlayers.Name = "lblPlayers";
            this.lblPlayers.Size = new System.Drawing.Size(60, 20);
            this.lblPlayers.TabIndex = 4;
            this.lblPlayers.Text = "Players";
            // 
            // lblGuilds
            // 
            this.lblGuilds.AutoSize = true;
            this.lblGuilds.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuilds.ForeColor = System.Drawing.Color.White;
            this.lblGuilds.Location = new System.Drawing.Point(715, 50);
            this.lblGuilds.Name = "lblGuilds";
            this.lblGuilds.Size = new System.Drawing.Size(54, 20);
            this.lblGuilds.TabIndex = 7;
            this.lblGuilds.Text = "Guilds";
            // 
            // lblO
            // 
            this.lblO.AutoSize = true;
            this.lblO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblO.ForeColor = System.Drawing.Color.White;
            this.lblO.Location = new System.Drawing.Point(40, 502);
            this.lblO.Name = "lblO";
            this.lblO.Size = new System.Drawing.Size(66, 24);
            this.lblO.TabIndex = 9;
            this.lblO.Text = "Output";
            // 
            // lsBoxPlayers
            // 
            this.lsBoxPlayers.BackColor = System.Drawing.Color.Silver;
            this.lsBoxPlayers.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsBoxPlayers.ForeColor = System.Drawing.Color.Black;
            this.lsBoxPlayers.FormattingEnabled = true;
            this.lsBoxPlayers.ItemHeight = 14;
            this.lsBoxPlayers.Location = new System.Drawing.Point(474, 73);
            this.lsBoxPlayers.Name = "lsBoxPlayers";
            this.lsBoxPlayers.Size = new System.Drawing.Size(219, 410);
            this.lsBoxPlayers.TabIndex = 11;
            this.lsBoxPlayers.SelectedIndexChanged += new System.EventHandler(this.Box_Players_Index_Changed);
            // 
            // lsBoxGuilds
            // 
            this.lsBoxGuilds.BackColor = System.Drawing.Color.Silver;
            this.lsBoxGuilds.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsBoxGuilds.ForeColor = System.Drawing.Color.Black;
            this.lsBoxGuilds.FormattingEnabled = true;
            this.lsBoxGuilds.ItemHeight = 14;
            this.lsBoxGuilds.Location = new System.Drawing.Point(719, 73);
            this.lsBoxGuilds.Name = "lsBoxGuilds";
            this.lsBoxGuilds.Size = new System.Drawing.Size(306, 410);
            this.lsBoxGuilds.TabIndex = 12;
            // 
            // rTextBox
            // 
            this.rTextBox.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rTextBox.Location = new System.Drawing.Point(44, 529);
            this.rTextBox.Name = "rTextBox";
            this.rTextBox.Size = new System.Drawing.Size(981, 152);
            this.rTextBox.TabIndex = 13;
            this.rTextBox.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1069, 749);
            this.Controls.Add(this.rTextBox);
            this.Controls.Add(this.lsBoxGuilds);
            this.Controls.Add(this.lsBoxPlayers);
            this.Controls.Add(this.lblO);
            this.Controls.Add(this.lblGuilds);
            this.Controls.Add(this.lblPlayers);
            this.Controls.Add(this.lblSystem);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblSearchGuild;
        private System.Windows.Forms.Label lblSearchPlayer;
        private System.Windows.Forms.TextBox txtSearchServer;
        private System.Windows.Forms.TextBox txtSearchPlayer;
        private System.Windows.Forms.Button btnApplySearch;
        private System.Windows.Forms.Button btnLeaveGuild;
        private System.Windows.Forms.Button btnJoinGuild;
        private System.Windows.Forms.Button btnDisbandGuild;
        private System.Windows.Forms.Button btnPrintGuild;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label lblRace;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.Button btnAddPlayer;
        private System.Windows.Forms.ComboBox cbRole;
        private System.Windows.Forms.ComboBox cbClass;
        private System.Windows.Forms.ComboBox cbRace;
        private System.Windows.Forms.TextBox txtPlayerName;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAddGuild;
        private System.Windows.Forms.ComboBox cbType;
        private System.Windows.Forms.ComboBox cbServer;
        private System.Windows.Forms.TextBox txtGuildName;
        private System.Windows.Forms.Label lblSystem;
        private System.Windows.Forms.Label lblPlayers;
        private System.Windows.Forms.Label lblGuilds;
        private System.Windows.Forms.Label lblO;
        private System.Windows.Forms.ListBox lsBoxPlayers;
        private System.Windows.Forms.ListBox lsBoxGuilds;
        private System.Windows.Forms.RichTextBox rTextBox;
    }
}

